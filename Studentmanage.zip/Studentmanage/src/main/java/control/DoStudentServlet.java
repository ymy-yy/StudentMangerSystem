package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DoStudentServlet.do")
public class DoStudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        int age = Integer.parseInt(request.getParameter("age"));
        String grade = request.getParameter("grade");
        float score = Float.parseFloat(request.getParameter("score"));
        
        Student stu = new Student();
        stu.setId(id);
        stu.setName(name);
        stu.setSex(sex);
        stu.setAge(age);
        stu.setGrade(grade);
        stu.setScore(score);
        
        StudentModel model = new StudentModel();
        model.updateStudent(stu);
        
        response.sendRedirect("ListStudentServlet.do");
    }
}