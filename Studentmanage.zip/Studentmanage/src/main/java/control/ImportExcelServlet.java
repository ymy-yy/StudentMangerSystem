package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

@WebServlet("/ImportExcelServlet.do")
@MultipartConfig(maxFileSize = 1024 * 1024 * 10)
public class ImportExcelServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        Part filePart = request.getPart("excelFile");
        String fileName = filePart.getSubmittedFileName();
        
        if (!fileName.endsWith(".xlsx") && !fileName.endsWith(".xls")) {
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write("<script>alert('请上传Excel文件（.xlsx或.xls格式）'); history.back();</script>");
            return;
        }
        
        List<Student> studentList = new ArrayList<>();
        int successCount = 0;
        int failCount = 0;
        
        try (InputStream is = filePart.getInputStream()) {
            Workbook workbook;
            if (fileName.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(is);
            } else {
                workbook = new HSSFWorkbook(is);
            }
            
            Sheet sheet = workbook.getSheetAt(0);
            
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                
                Cell firstCell = row.getCell(0);
                if (firstCell == null || getCellValue(firstCell).trim().isEmpty()) continue;
                
                String name = getCellValue(row.getCell(0));
                String sex = getCellValue(row.getCell(1));
                String ageStr = getCellValue(row.getCell(2));
                String grade = getCellValue(row.getCell(3));
                String scoreStr = getCellValue(row.getCell(4));
                
                if (name == null || name.trim().isEmpty()) {
                    failCount++;
                    continue;
                }
                
                Student stu = new Student();
                stu.setName(name.trim());
                stu.setSex(sex != null && !sex.trim().isEmpty() ? sex.trim() : "男");
                
                try {
                    stu.setAge(ageStr != null && !ageStr.isEmpty() ? (int) Double.parseDouble(ageStr) : 0);
                } catch (NumberFormatException e) {
                    stu.setAge(0);
                }
                
                stu.setGrade(grade != null ? grade.trim() : "");
                
                try {
                    stu.setScore(scoreStr != null && !scoreStr.isEmpty() ? Float.parseFloat(scoreStr) : 0);
                } catch (NumberFormatException e) {
                    stu.setScore(0);
                }
                
                studentList.add(stu);
            }
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write("<script>alert('解析Excel文件失败：" + e.getMessage() + "'); history.back();</script>");
            return;
        }
        
        StudentModel model = new StudentModel();
        for (Student stu : studentList) {
            if (model.insertStudent(stu)) {
                successCount++;
            } else {
                failCount++;
            }
        }
        
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write("<script>alert('导入完成！\\n成功：" + successCount + "条\\n失败：" + failCount + "条'); window.location.href='ListStudentServlet.do';</script>");
    }
    
    // 获取单元格的值
    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    double num = cell.getNumericCellValue();
                    if (num == (int) num) {
                        return String.valueOf((int) num);
                    }
                    return String.valueOf(num);
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                try {
                    return String.valueOf(cell.getNumericCellValue());
                } catch (Exception e) {
                    return cell.getStringCellValue();
                }
            default:
                return "";
        }
    }
}