package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InsertStudentServlet.do")
public class InsertStudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        String ageStr = request.getParameter("age");
        String grade = request.getParameter("grade");
        String scoreStr = request.getParameter("score");
        
        if (name == null || name.trim().isEmpty()) {
            response.sendRedirect("jsp/studentinsert.jsp?error=1");
            return;
        }
        
        Student stu = new Student();
        stu.setName(name);
        stu.setSex(sex);
        stu.setAge(ageStr != null && !ageStr.isEmpty() ? Integer.parseInt(ageStr) : 0);
        stu.setGrade(grade);
        stu.setScore(scoreStr != null && !scoreStr.isEmpty() ? Float.parseFloat(scoreStr) : 0);
        
        StudentModel model = new StudentModel();
        boolean success = model.insertStudent(stu);
        
        if (success) {
            response.sendRedirect("ListStudentServlet.do");
        } else {
            response.sendRedirect("jsp/studentinsert.jsp?error=2");
        }
    }
}