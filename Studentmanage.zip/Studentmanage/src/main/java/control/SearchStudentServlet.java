package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SearchStudentServlet.do")
public class SearchStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String keyword = request.getParameter("keyword");
        StudentModel model = new StudentModel();
        List<Student> studentList;
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            studentList = model.searchStudents(keyword.trim());
        } else {
            studentList = model.getAllStudents();
        }
        
        request.setAttribute("studentList", studentList);
        request.setAttribute("keyword", keyword);
        request.getRequestDispatcher("/jsp/studentlist.jsp").forward(request, response);
    }
}