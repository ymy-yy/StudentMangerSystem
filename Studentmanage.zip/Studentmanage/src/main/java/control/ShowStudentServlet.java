package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ShowStudentServlet.do")
public class ShowStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            StudentModel model = new StudentModel();
            Student stu = model.getStudentById(id);
            request.setAttribute("student", stu);
        }
        request.getRequestDispatcher("/jsp/studentshow.jsp").forward(request, response);
    }
}