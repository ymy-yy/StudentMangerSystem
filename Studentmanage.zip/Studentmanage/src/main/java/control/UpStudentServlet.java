package control;

import model.StudentModel;
import entity.Student;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpStudentServlet.do")
public class UpStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            StudentModel model = new StudentModel();
            Student stu = model.getStudentById(id);
            request.setAttribute("student", stu);
        }
        request.getRequestDispatcher("/jsp/studentupdate.jsp").forward(request, response);
    }
}