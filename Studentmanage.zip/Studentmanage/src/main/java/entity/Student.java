package entity;

public class Student {
    private int id;
    private String name;
    private String sex;
    private int age;
    private String grade;
    private float score;

    public Student() {}

    public Student(int id, String name, String sex, int age, String grade, float score) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.grade = grade;
        this.score = score;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public float getScore() { return score; }
    public void setScore(float score) { this.score = score; }
}