package model;

import dbutil.Dbconn;
import entity.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentModel {

    // 1. 查询所有学生
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM student ORDER BY id";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = Dbconn.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Student stu = new Student();
                stu.setId(rs.getInt("id"));
                stu.setName(rs.getString("name"));
                stu.setSex(rs.getString("sex"));
                stu.setAge(rs.getInt("age"));
                stu.setGrade(rs.getString("grade"));
                stu.setScore(rs.getFloat("score"));
                list.add(stu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Dbconn.closeAll(rs, stmt, conn);
        }
        return list;
    }

    // 2. 根据ID查询单个学生
    public Student getStudentById(int id) {
        String sql = "SELECT * FROM student WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Student stu = null;
        try {
            conn = Dbconn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                stu = new Student();
                stu.setId(rs.getInt("id"));
                stu.setName(rs.getString("name"));
                stu.setSex(rs.getString("sex"));
                stu.setAge(rs.getInt("age"));
                stu.setGrade(rs.getString("grade"));
                stu.setScore(rs.getFloat("score"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Dbconn.closeAll(rs, pstmt, conn);
        }
        return stu;
    }

    // 3. 新增学生
    public boolean insertStudent(Student stu) {
        String sql = "INSERT INTO student (name, sex, age, grade, score) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = Dbconn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, stu.getName());
            pstmt.setString(2, stu.getSex());
            pstmt.setInt(3, stu.getAge());
            pstmt.setString(4, stu.getGrade());
            pstmt.setFloat(5, stu.getScore());
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Dbconn.close(pstmt);
            Dbconn.close(conn);
        }
    }

    // 4. 更新学生信息
    public boolean updateStudent(Student stu) {
        String sql = "UPDATE student SET name=?, sex=?, age=?, grade=?, score=? WHERE id=?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = Dbconn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, stu.getName());
            pstmt.setString(2, stu.getSex());
            pstmt.setInt(3, stu.getAge());
            pstmt.setString(4, stu.getGrade());
            pstmt.setFloat(5, stu.getScore());
            pstmt.setInt(6, stu.getId());
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Dbconn.close(pstmt);
            Dbconn.close(conn);
        }
    }

    // 5. 删除学生
    public boolean deleteStudentById(int id) {
        String sql = "DELETE FROM student WHERE id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = Dbconn.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            Dbconn.close(pstmt);
            Dbconn.close(conn);
        }
    }
    
 // 6. 搜索学生（按姓名或班级模糊查询）
    public List<Student> searchStudents(String keyword) {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM student WHERE name LIKE ? OR grade LIKE ? ORDER BY id";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = Dbconn.getConnection();
            pstmt = conn.prepareStatement(sql);
            String likeKeyword = "%" + keyword + "%";
            pstmt.setString(1, likeKeyword);
            pstmt.setString(2, likeKeyword);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Student stu = new Student();
                stu.setId(rs.getInt("id"));
                stu.setName(rs.getString("name"));
                stu.setSex(rs.getString("sex"));
                stu.setAge(rs.getInt("age"));
                stu.setGrade(rs.getString("grade"));
                stu.setScore(rs.getFloat("score"));
                list.add(stu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Dbconn.close(rs);
            Dbconn.close(pstmt);
            Dbconn.close(conn);
        }
        return list;
    }
}