<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>新增学生 - 学生管理系统</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <div class="form-container">
        <div class="form-title">
            <h2>➕ 新增学生</h2>
            <p style="color: #6c757d; font-size: 14px; margin-top: 5px;">填写学生信息，点击提交</p>
        </div>
        
        <% if (request.getParameter("error") != null) { %>
            <div class="alert alert-error">❌ 添加失败，请检查信息是否完整或学号是否重复</div>
        <% } %>
        
        <form action="${pageContext.request.contextPath}/InsertStudentServlet.do" method="post">
            <div class="form-group">
                <label>👤 姓名 <span style="color: red;">*</span></label>
                <input type="text" name="name" placeholder="请输入学生姓名" required>
            </div>
            <div class="form-group">
                <label>⚥ 性别</label>
                <select name="sex">
                    <option value="男">男</option>
                    <option value="女">女</option>
                </select>
            </div>
            <div class="form-group">
                <label>📅 年龄</label>
                <input type="number" name="age" placeholder="请输入年龄" min="1" max="100">
            </div>
            <div class="form-group">
                <label>🏫 班级</label>
                <input type="text" name="grade" placeholder="请输入班级">
            </div>
            <div class="form-group">
                <label>📊 分数</label>
                <input type="number" step="0.1" name="score" placeholder="请输入分数" min="0" max="100">
            </div>
            <button type="submit" class="btn-submit">✅ 提交保存</button>
            <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="btn-back">← 返回列表</a>
        </form>
    </div>
</body>
</html>