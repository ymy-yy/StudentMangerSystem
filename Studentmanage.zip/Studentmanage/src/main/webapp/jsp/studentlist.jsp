<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="entity.Student, java.util.List" %>
<html>
<head>
    <title>学生信息管理系统 - 首页</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 学生信息管理系统</h1>
            <p>学生信息管理 | 数据可视化 | 高效便捷</p>
        </div>
        
        <div class="nav-bar">
            <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="nav-btn">🏠 首页</a>
            <a href="${pageContext.request.contextPath}/jsp/studentinsert.jsp" class="nav-btn">➕ 新增学生</a>
            <a href="${pageContext.request.contextPath}/jsp/upload.jsp" class="nav-btn">📎 批量导入</a>
        </div>
        <!-- 在 </div class="nav-bar"> 后面添加 -->
<div style="padding: 15px 30px; background: white; border-bottom: 1px solid #e9ecef;">
    <form action="${pageContext.request.contextPath}/SearchStudentServlet.do" method="get" style="display: flex; gap: 10px; align-items: center;">
        <input type="text" name="keyword" placeholder="🔍 输入姓名或班级搜索..." style="flex: 1; padding: 10px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 14px;">
        <button type="submit" style="padding: 10px 25px; background: #667eea; color: white; border: none; border-radius: 10px; cursor: pointer;">搜索</button>
        <a href="${pageContext.request.contextPath}/ListStudentServlet.do" style="padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 10px;">重置</a>
    </form>
</div>
        
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th><th>姓名</th><th>性别</th><th>年龄</th><th>班级</th><th>分数</th><th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        List<Student> studentList = (List<Student>) request.getAttribute("studentList");
                        if (studentList != null && !studentList.isEmpty()) {
                            for (Student stu : studentList) {
                    %>
                    <tr>
                        <td><%= stu.getId() %></td>
                        <td><strong><%= stu.getName() %></strong></td>
                        <td><%= stu.getSex() %></td>
                        <td><%= stu.getAge() %></td>
                        <td><%= stu.getGrade() %></td>
                        <td><%= stu.getScore() %></td>
                        <td>
                            <a href="ShowStudentServlet.do?id=<%= stu.getId() %>" class="action-btn detail">📋 详情</a>
                            <a href="UpStudentServlet.do?id=<%= stu.getId() %>" class="action-btn edit">✏️ 修改</a>
                            <a href="DeleteStudentServlet.do?id=<%= stu.getId() %>" class="action-btn delete" onclick="return confirm('确定要删除学生「<%= stu.getName() %>」吗？')">🗑️ 删除</a>
                        </td>
                    </tr>
                    <%
                            }
                        } else {
                    %>
                    <tr class="empty-row">
                        <td colspan="7">📭 暂无学生数据，请点击「新增学生」添加</td>
                    </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>© 2024 学生信息管理系统 | 数据实时同步 | 安全可靠</p>
        </div>
    </div>
</body>
</html>