<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="entity.Student" %>
<html>
<head>
    <title>学生详情 - 学生管理系统</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <%
        Student stu = (Student) request.getAttribute("student");
        if (stu != null) {
    %>
    <div class="detail-container">
        <div class="detail-header">
            <h2>📋 学生详细信息</h2>
            <p>学生ID: <%= stu.getId() %></p>
        </div>
        <div class="detail-content">
            <div class="detail-row">
                <div class="detail-label">👤 姓名：</div>
                <div class="detail-value"><strong><%= stu.getName() %></strong></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">⚥ 性别：</div>
                <div class="detail-value"><%= stu.getSex() %></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">📅 年龄：</div>
                <div class="detail-value"><%= stu.getAge() %> 岁</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">🏫 班级：</div>
                <div class="detail-value"><%= stu.getGrade() %></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">📊 分数：</div>
                <div class="detail-value"><%= stu.getScore() %> 分</div>
            </div>
        </div>
        <div style="padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
            <a href="UpStudentServlet.do?id=<%= stu.getId() %>" class="action-btn edit" style="margin-right: 10px;">✏️ 修改信息</a>
            <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="action-btn detail">← 返回列表</a>
        </div>
    </div>
    <% } else { %>
    <div class="form-container">
        <div class="alert alert-error">❌ 学生信息不存在</div>
        <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="btn-back">← 返回列表</a>
    </div>
    <% } %>
</body>
</html>