<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="entity.Student" %>
<html>
<head>
    <title>修改学生信息 - 学生管理系统</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <%
        Student stu = (Student) request.getAttribute("student");
        if (stu != null) {
    %>
    <div class="form-container">
        <div class="form-title">
            <h2>✏️ 修改学生信息</h2>
            <p style="color: #6c757d; font-size: 14px;">修改学生「<%= stu.getName() %>」的信息</p>
        </div>
        
        <form action="${pageContext.request.contextPath}/DoStudentServlet.do" method="post">
            <input type="hidden" name="id" value="<%= stu.getId() %>">
            <div class="form-group">
                <label>👤 姓名</label>
                <input type="text" name="name" value="<%= stu.getName() %>" required>
            </div>
            <div class="form-group">
                <label>⚥ 性别</label>
                <select name="sex">
                    <option value="男" <%= "男".equals(stu.getSex()) ? "selected" : "" %>>男</option>
                    <option value="女" <%= "女".equals(stu.getSex()) ? "selected" : "" %>>女</option>
                </select>
            </div>
            <div class="form-group">
                <label>📅 年龄</label>
                <input type="number" name="age" value="<%= stu.getAge() %>">
            </div>
            <div class="form-group">
                <label>🏫 班级</label>
                <input type="text" name="grade" value="<%= stu.getGrade() %>">
            </div>
            <div class="form-group">
                <label>📊 分数</label>
                <input type="number" step="0.1" name="score" value="<%= stu.getScore() %>">
            </div>
            <button type="submit" class="btn-submit">💾 保存修改</button>
            <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="btn-back">← 返回列表</a>
        </form>
    </div>
    <% } else { %>
    <div class="form-container">
        <div class="alert alert-error">❌ 学生信息不存在</div>
        <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="btn-back">← 返回列表</a>
    </div>
    <% } %>
</body>
</html>