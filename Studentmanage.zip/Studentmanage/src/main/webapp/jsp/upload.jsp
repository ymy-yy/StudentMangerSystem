<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>批量导入 - 学生管理系统</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <div class="upload-container">
        <div class="upload-icon">📎</div>
        <h2>Excel批量导入学生</h2>
        <p style="color: #6c757d; margin-bottom: 20px;">快速导入学生数据，支持.xlsx和.xls格式</p>
        
        <div class="upload-area">
            <form action="${pageContext.request.contextPath}/ImportExcelServlet.do" method="post" enctype="multipart/form-data">
                <input type="file" name="excelFile" accept=".xlsx,.xls" required style="margin-bottom: 20px;"><br>
                <button type="submit" class="btn-submit" style="width: auto; padding: 12px 30px;">📤 上传并导入</button>
                <a href="${pageContext.request.contextPath}/ListStudentServlet.do" class="btn-back" style="display: inline-block; margin-left: 15px;">← 返回列表</a>
            </form>
        </div>
        
        <div style="margin-top: 30px; text-align: left; background: #f8f9fa; padding: 15px; border-radius: 10px;">
            <p style="font-weight: bold; margin-bottom: 10px;">📌 Excel文件格式要求：</p>
            <p>第1行（表头）：<strong>姓名 | 性别 | 年龄 | 班级 | 分数</strong></p>
            <p>第2行开始：<strong>张三 | 男 | 20 | 计算机1班 | 85.5</strong></p>
            <p style="color: #dc3545; margin-top: 10px;">⚠️ 注意：姓名不能为空，年龄和分数为数字</p>
        </div>
        
        <div class="footer" style="margin-top: 30px; background: none; border: none;">
            <p>💡 提示：可以下载模板填写后上传</p>
        </div>
    </div>
</body>
</html>